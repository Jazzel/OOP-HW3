#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "node.hpp"
#include <cstring>
#include <fstream>

using namespace std;

BSTNode *root = NULL; // this is the root of BST

// Default Constructor definition.
BSTNode ::BSTNode()
    : val({}), left(NULL), right(NULL)
{
}

// Parameterized Constructor definition.
BSTNode ::BSTNode(Truck truck)
{
   val = truck;
   left = right = NULL;
}

BSTNode *BSTNode::insert(BSTNode *temp, Truck truck)
{
   if (!temp)
   {
      return new BSTNode(truck);
   }
   cout << temp->val.driver << endl;
   // Insert data.
   if (truck.regNo > temp->val.regNo)
   {
      temp->right = insert(temp->right, truck);
   }
   else
   {
      temp->left = insert(temp->left, truck);
   }

   return temp;
}

void BSTNode ::Inorder(BSTNode *root)
{
   if (!root)
   {
      return;
   }
   Inorder(root->left);
   cout << root->val.driver << endl;
   Inorder(root->right);
}

// You have to define the functions below
void loadTrucks()
{
   BSTNode b;

   ifstream file("input.txt");
   // file.open("input.txt", ios::out | ios::in);

   string driver, petrol, regNo, fullMileage, emptyMileage;

   while (file.eof() == 0)
   {
      getline(file, driver);
      getline(file, petrol);
      getline(file, regNo);
      getline(file, fullMileage);
      getline(file, emptyMileage);

      Truck truck;
      truck.driver = driver;
      truck.petrol = stod(petrol);
      truck.regNo = regNo;
      truck.fullMileage = stoi(fullMileage);
      truck.emptyMileage = stoi(emptyMileage);
      b.insert(root, truck);
   }
   b.Inorder(root);

   file.close();
}

void makeJourney()
{
   // b.Inorder(root);
}

void unloadTrucks()
{
}

int main()
{
   // BSTNode b;

   loadTrucks();
   makeJourney();
   unloadTrucks();
   return 0;
}
