#pragma once
#include "truck.hpp"

class BSTNode
{
public:
    Truck val;
    BSTNode *left;
    BSTNode *right;

public:
    BSTNode();

    BSTNode(Truck);

    void Inorder(BSTNode *);
    BSTNode *insert(BSTNode *, Truck);
};