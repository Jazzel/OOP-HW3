#pragma once
#include <iostream>
using namespace std;

struct Truck
{
    string driver;
    double petrol;
    string regNo;
    int fullMileage;
    int emptyMileage;
};
